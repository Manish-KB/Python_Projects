>>Update your Chrome Browser

>>Run the following commands

pip install -r requirements.txt
python gform.py